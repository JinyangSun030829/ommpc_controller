#include <ros/ros.h>
#include <limits>
#include <mavros_msgs/State.h>
#include <mavros_msgs/ExtendedState.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/AttitudeTarget.h>
#include <dynamic_reconfigure/server.h>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/Vector3Stamped.h>
#include <std_msgs/Float64MultiArray.h>
#include "disturbance_observer.hpp"
#include "ommpc_controller.hpp"
#include "ommpc_controller/fsm_changeConfig.h"

#include <ros/package.h>
#include <fstream>

enum Exec_Traj_State_t
{
    HOVER = 10,     // execute the hover trajectory
    POLY_TRAJ = 11, // execute the polynomial trajectory
    POINTS = 12,    // execute the point trajectory (txt)
    TAKEOFF = 13,
    LAND = 14
};

class OMMPC_EXAMPLE{
private:
    ros::NodeHandle node_;
    ros::Publisher cmd_pub_;
    ros::Publisher reference_position_pub_;
    // DOB debug publishers
    ros::Publisher dob_raw_pub_;
    ros::Publisher dob_filtered_pub_;
    ros::Publisher dob_comp_pub_;
    ros::Publisher dob_dot_pub_;
    ros::Publisher dob_nominal_acc_pub_;
    ros::Publisher dob_velocity_error_pub_;
    ros::Publisher dob_status_pub_;
    ros::Subscriber odom_sub_, imu_sub_, state_sub_, mpc_traj_sub_;
    ros::Subscriber extended_state_sub_;
    ros::ServiceClient set_mode_client_, arming_client_srv_;
    ros::Timer exec_timer_, read_file_timer_;
    mavros_msgs::State state_;
    mavros_msgs::ExtendedState extended_state_;
    Odom_Data_t odom_data_;
    Imu_Data_t imu_data_;
    Exec_Traj_State_t exec_traj_state_;
    Parameter_t param_;
    Trajectory_Data_t trajectory_data_;
    MpcController ommpc_controller_;
    Controller_Output_t last_u_;
    bool is_command_mode_ = false;
    bool takeoff_enabled_ = false, last_takeoff_enabled_ = false, takeoff_trigger_ = false;
    bool land_enabled_ = false, last_land_enabled_ = false, land_trigger_ = false;
    bool has_takeoff_ = false, has_land_ = true;
    // 表示物理上是否已经离地
    // 与“起飞流程是否完整完成”不是同一个概念
    bool is_airborne_ = false;
    bool dob_airborne_active_ = false;
    // 只有起飞完成后新收到的轨迹才能置 true
    bool trajectory_ready_ = false;
    bool odom_ready_ = false;
    bool hover_initialized_ = false;
    // 用于拒绝起飞前生成的旧轨迹
    ros::Time takeoff_complete_stamp_;
    // 本次飞行起飞地面高度
    double takeoff_ground_z_ = 0.0;
    bool takeoff_ground_z_valid_ = false;
    ros::Time landing_detect_start_;
    ros::Time last_disarm_attempt_;
    bool landing_detect_active_ = false;
    bool extended_state_ready_ = false;
    bool touchdown_unload_active_ = false;
    ros::Time touchdown_unload_start_;
    double touchdown_start_thrust_ = 0.0;
    int consecutive_failures_ = 0;
    double start_takeoff_land_time;
    bool enu_frame_, vel_in_body_;
    Eigen::Vector4d hover_pose_;

    int line_cnt_ = 0, number_of_steps_ = 0;
    std::vector<std::vector<double>> test_trajectory_;
    std::vector<Eigen::Vector3d> quad_positions_;
	std::vector<Eigen::Vector3d> quad_velocities_;
	std::vector<double> yaws_;

    dynamic_reconfigure::Server<ommpc_controller::fsm_changeConfig> state_change_server_;
    dynamic_reconfigure::Server<ommpc_controller::fsm_changeConfig>::CallbackType state_change_cb_type_;
    geometry_msgs::Vector3Stamped makeVector3Msg(
    const ros::Time &stamp,
    const Eigen::Vector3d &value,
    const std::string &frame_id =
            "world") const
    {
        geometry_msgs::Vector3Stamped msg;

        msg.header.stamp =
            stamp.isZero()
                ? ros::Time::now()
                : stamp;

        msg.header.frame_id =
            frame_id;

        msg.vector.x = value.x();
        msg.vector.y = value.y();
        msg.vector.z = value.z();

        return msg;
    }
    void MpcTrajectoryCallback(
        const traj_utils::PolyTraj::ConstPtr &msg)
    {
        /**********************************************************
         * 接收轨迹的第一层安全门
         **********************************************************/

        const bool flight_ready =
            has_takeoff_ &&
            exec_traj_state_ == HOVER &&
            state_.armed &&
            state_.mode ==
                mavros_msgs::State::MODE_PX4_OFFBOARD &&
            is_command_mode_;

        /*
        * 非飞行就绪状态下收到的轨迹直接丢弃。
        *
        * 尤其包括：
        *
        * 地面
        * TAKEOFF
        * LAND
        * 未解锁
        * 非OFFBOARD
        * 非command mode
        */
        if (!flight_ready)
        {
            ROS_WARN_THROTTLE(
                1.0,
                "[TRAJ SAFETY] Trajectory rejected. "
                "has_takeoff=%d, state=%d, armed=%d, "
                "offboard=%d, command_mode=%d",
                static_cast<int>(has_takeoff_),
                static_cast<int>(exec_traj_state_),
                static_cast<int>(state_.armed),
                static_cast<int>(
                    state_.mode ==
                    mavros_msgs::State::
                        MODE_PX4_OFFBOARD),
                static_cast<int>(is_command_mode_));

            return;
        }

        /*
        * 到这里才真正把轨迹交给原来的解析器。
        */
        trajectory_data_
            .feed_from_traj_utils(msg);

        /**********************************************************
         * 第二层检查：轨迹解析是否正常
         **********************************************************/

        if (trajectory_data_.traj_queue.empty() ||
            trajectory_data_.exec_traj != 1)
        {
            clearTrajectoryCommand(
                "received trajectory is invalid");

            return;
        }

        const ros::Time now =
            ros::Time::now();

        /**********************************************************
         * 第三层检查：拒绝已经过期的轨迹
         **********************************************************/

        if (trajectory_data_
                .total_traj_end_time <= now)
        {
            clearTrajectoryCommand(
                "received trajectory already expired");

            return;
        }

        /**********************************************************
         * 第四层检查：
         *
         * 轨迹开始时间不能早于本次起飞完成时间。
         *
         * 这样即使规划器把起飞前的旧轨迹重新发过来，
         * 也不会立即执行。
         **********************************************************/

        if (trajectory_data_
                .total_traj_start_time <
            takeoff_complete_stamp_)
        {
            clearTrajectoryCommand(
                "trajectory was generated before takeoff completed");

            return;
        }

        /**********************************************************
         * 通过所有检查后，才允许状态机执行。
         **********************************************************/

        trajectory_ready_ = true;

        ROS_WARN(
            "[TRAJ SAFETY] New trajectory accepted. "
            "Waiting for execution.");
    }
    void publishDOBDebug()
    {
        DobDebugData data;

        ommpc_controller_
            .getDobDebugData(data);

        const ros::Time stamp =
            data.stamp.isZero()
                ? ros::Time::now()
                : data.stamp;

        dob_raw_pub_.publish(
            makeVector3Msg(
                stamp,
                data.disturbance_raw));

        dob_filtered_pub_.publish(
            makeVector3Msg(
                stamp,
                data.disturbance_filtered));

        dob_comp_pub_.publish(
            makeVector3Msg(
                stamp,
                data.disturbance_comp));

        dob_dot_pub_.publish(
            makeVector3Msg(
                stamp,
                data.disturbance_dot_filtered));

        dob_nominal_acc_pub_.publish(
            makeVector3Msg(
                stamp,
                data.nominal_acceleration));

        dob_velocity_error_pub_.publish(
            makeVector3Msg(
                stamp,
                data.velocity_error));

        /*
        * status.data 索引定义：
        *
        * [0] enable
        * [1] initialized
        * [2] input_valid
        * [3] delayed_thrustacc [m/s^2]
        * [4] observer_dt [s]
        * [5] ramp
        */
        std_msgs::Float64MultiArray status;

        status.layout.dim.resize(1);
        status.layout.dim[0].label =
            "enable,initialized,input_valid,"
            "delayed_thrustacc,observer_dt,ramp";

        status.layout.dim[0].size = 6;
        status.layout.dim[0].stride = 6;

        status.data.resize(6);

        status.data[0] =
            data.enabled ? 1.0 : 0.0;

        status.data[1] =
            data.initialized ? 1.0 : 0.0;

        status.data[2] =
            data.input_valid ? 1.0 : 0.0;

        status.data[3] =
            data.delayed_thrustacc;

        status.data[4] =
            data.observer_dt;

        status.data[5] =
            data.ramp;

        dob_status_pub_.publish(status);
    }
    void publishReferencePosition()
    {
        Eigen::Vector3d ref_position;

        if (!ommpc_controller_.getCurrentReferencePosition(ref_position))
        {
            return;
        }

        geometry_msgs::PointStamped msg;

        msg.header.stamp = ros::Time::now();
        msg.header.frame_id = "world";

        msg.point.x = ref_position.x();
        msg.point.y = ref_position.y();
        msg.point.z = ref_position.z();

        reference_position_pub_.publish(msg);
    }
    void OdomCallback(const nav_msgs::Odometry::ConstPtr &msg){
        odom_data_.feed(msg, enu_frame_, vel_in_body_);
        odom_ready_ = true;

        /*
        * 第一次收到有效odom时，
        * 自动把当前位置设置为初始悬停点。
        */
        if (!hover_initialized_)
        {
            hover_pose_.head<3>() =odom_data_.p;
            hover_pose_(3) =get_yaw_from_quaternion(odom_data_.q);
            hover_initialized_ = true;
            ROS_INFO( "[FSM] Initial hover pose " "initialized from odometry.");
        }
    }
    void ExtendedStateCallback(const mavros_msgs::ExtendedState::ConstPtr &msg)
    {
        extended_state_ = *msg;
        extended_state_ready_ = true;
    }

    void IMUCallback(const sensor_msgs::Imu::ConstPtr &msg){
        imu_data_.feed(msg, enu_frame_);
    }

    void StateCallback(const mavros_msgs::State::ConstPtr &msg){
        state_ = *msg;
    }

    void stateChangeCallback(ommpc_controller::fsm_changeConfig &config, uint32_t level){
        last_takeoff_enabled_ = takeoff_enabled_;
        last_land_enabled_ = land_enabled_;
        land_enabled_ = config.land_enabled;
        is_command_mode_ = config.command_or_hover;
        takeoff_enabled_ = config.takeoff_enabled;
        if (last_takeoff_enabled_ == false && takeoff_enabled_ == true)
        {
            takeoff_trigger_ = true;
        }
        if (last_land_enabled_ == false && land_enabled_ == true)
        {
            land_trigger_ = true;
        }
    }

    void send_cmd(const Controller_Output_t &output){
        mavros_msgs::AttitudeTarget cmd;
        cmd.header.stamp = ros::Time::now();
        cmd.body_rate.x = output.bodyrates(0);
        cmd.body_rate.y = output.bodyrates(1);
        cmd.body_rate.z = output.bodyrates(2);
		if (output.thrust >= 0.9) cmd.thrust = 0.9;
		else if (output.thrust <= 0.04) cmd.thrust = 0.04;
        else cmd.thrust = output.thrust;
        cmd.type_mask = mavros_msgs::AttitudeTarget::IGNORE_ATTITUDE;
        cmd_pub_.publish(cmd);
        ommpc_controller_.recordAppliedControl(cmd.thrust,output.bodyrates,cmd.header.stamp);
    }
    void clearTrajectoryCommand(
        const std::string &reason)
    {
        trajectory_data_.traj_queue.clear();

        trajectory_data_.exec_traj = 0;

        trajectory_data_.total_traj_start_time =
            ros::Time(0);

        trajectory_data_.total_traj_end_time =
            ros::Time(0);

        trajectory_ready_ = false;

        ROS_WARN(
            "[TRAJ SAFETY] Trajectory cleared: %s",
            reason.c_str());
    }
    void set_hov_with_odom()
    {
        hover_pose_.head<3>() = odom_data_.p;
        hover_pose_(3) = get_yaw_from_quaternion(odom_data_.q);
    }

    double get_yaw_from_quaternion(const Eigen::Quaterniond& q) {
        return atan2(2 * (q.w() * q.z() + q.x() * q.y()), 1 - 2 * (q.y() * q.y() + q.z() * q.z()));
    }

    bool toggle_arm_disarm(bool arm)
    {
        mavros_msgs::CommandBool arm_cmd;

        arm_cmd.request.value =
            arm;

        /**********************************************************
         * 1. ROS service本身是否调用成功
         **********************************************************/
        if (!arming_client_srv_.call(arm_cmd))
        {
            ROS_ERROR(
                "%s service call failed!",
                arm ? "ARM" : "DISARM");

            return false;
        }

        /**********************************************************
         * 2. PX4是否接受命令
         **********************************************************/
        if (!arm_cmd.response.success)
        {
            ROS_ERROR(
                "%s rejected by PX4! "
                "MAV_RESULT=%u",
                arm ? "ARM" : "DISARM",
                static_cast<unsigned int>(
                    arm_cmd.response.result));

            return false;
        }

        ROS_INFO(
            "%s accepted by PX4. "
            "MAV_RESULT=%u",
            arm ? "ARM" : "DISARM",
            static_cast<unsigned int>(
                arm_cmd.response.result));

        return true;
    }

    bool execMPCAndPublish(Controller_Output_t &u)
    {
        bool result =
            ommpc_controller_.execMPC(odom_data_, u);

        if (result)
        {
            publishReferencePosition();
        }

        return result;
    }

    void execFSMCallback(const ros::TimerEvent &e){
        if (!ros::ok())
        {
            return;
        }
        exec_timer_.stop();

        Controller_Output_t u;
        u.bodyrates.setZero();
        u.thrust = 0.0; 
        bool ret = false;
        ros::Time now_time = ros::Time::now();
        const Exec_Traj_State_t state_before_control =exec_traj_state_;
        if (!odom_ready_ ||!hover_initialized_)
        {
            ROS_WARN_THROTTLE(1.0,"[FSM] Waiting for valid odometry.");
            if (ros::ok())
            {
                exec_timer_.start();
            }

            return;
        }
         const double odom_age =(now_time -odom_data_.rcv_stamp).toSec();

        if (odom_age > 0.10)
        {
            ROS_ERROR_THROTTLE(0.5,"[FSM] Odom timeout %.3f s",odom_age);
            Controller_Output_t safe_u = last_u_;
            send_cmd(safe_u); 
            // 【修改结束】
            if (ros::ok())
            {
                exec_timer_.start();
            }
            return;
        }
         /**********************************************************
         * Update translational disturbance observer
         *
         * 必须放在 setTrajectoryReference()、
         * setTextReference() 和 setHoverReference() 之前，
         * 因为这些函数需要使用本周期最新的扰动估计。
         **********************************************************/
        /**********************************************************
         * DOB activation logic
         *
         * 目标：
         * 1. 地面等待时不运行 DOB
         * 2. TAKEOFF 真正离地后启动 DOB
         * 3. TAKEOFF / HOVER / trajectory 持续运行 DOB
         * 4. LAND 高空阶段继续运行 DOB
         * 5. LAND 距离地面 <= landing_disable_height 时关闭 DOB
         **********************************************************/

        const bool offboard_and_armed =
            state_.mode ==
                mavros_msgs::State::MODE_PX4_OFFBOARD &&
            state_.armed;

        /*
        * 判断这一周期是不是刚刚检测到离地。
        *
        * 用于防止startDisturbanceObserver()之后
        * 同一个周期又立即update一次。
        */
        bool dob_just_started = false;

        /**********************************************************
         * 1. 检测真正离地
         **********************************************************/
        if (offboard_and_armed &&
            exec_traj_state_ == TAKEOFF &&
            !is_airborne_)
        {
            const double delta_z =
                odom_data_.p(2) -
                hover_pose_(2);

            const double vz =
                odom_data_.v(2);

            const bool liftoff_detected =
                delta_z >
                    param_.dob_liftoff_height &&
                vz >
                    param_.dob_liftoff_vz;

            if (liftoff_detected)
            {
                is_airborne_ = true;

                ROS_WARN(
                    "[FSM] LIFTOFF detected. "
                    "dz=%.3f, vz=%.3f",
                    delta_z,
                    vz);
            }
        }
        if (param_.dob_enable &&is_airborne_ && !dob_airborne_active_ &&
            exec_traj_state_ != LAND && offboard_and_armed)
        {
            dob_airborne_active_ = true;
            ommpc_controller_.startDisturbanceObserver(odom_data_);
            dob_just_started = true;
            ROS_WARN("[DOB] Observer activated.");
        }

        /**********************************************************
         * 2. 已经离地以后持续运行
         **********************************************************/
        /**********************************************************
         * 2. 判断当前DOB是否允许运行
         *
         * LAND阶段：
         *   > 0.10 m    DOB继续运行
         *   <= 0.10 m   DOB关闭并清零补偿
         **********************************************************/

        double height_above_ground =
            std::numeric_limits<double>::infinity();

        /*
        * 默认允许DOB继续运行。
        *
        * 只有LAND并且已经接近地面时才禁止。
        */
        bool dob_near_ground_disable = false;
        const bool landing_or_entering_land =
            exec_traj_state_ == LAND ||
            (exec_traj_state_ == HOVER &&
            land_trigger_ &&
            is_airborne_);

        if (landing_or_entering_land)
        {
            /*
            * LAND期间必须有有效地面高度，
            * 否则为了安全直接关闭DOB。
            */
            if (takeoff_ground_z_valid_)
            {
                height_above_ground =
                    odom_data_.p(2) -
                    takeoff_ground_z_;

                if (height_above_ground <=
                    param_.dob_landing_disable_height)
                {
                    dob_near_ground_disable =
                        true;
                }
            }
            else
            {
                /*
                * 无法确定实际离地高度时，
                * LAND阶段不继续做DOB补偿。
                */
                dob_near_ground_disable =
                    true;
            }
        }

        /**********************************************************
         * 3. DOB正常运行条件
         *
         * 注意：
         * 这里已经不再禁止整个LAND状态。
         **********************************************************/
        const bool dob_should_run =
            param_.dob_enable &&
            offboard_and_armed &&
            dob_airborne_active_ &&
            !dob_near_ground_disable;

        if (dob_should_run &&
            !dob_just_started)
        {
            ommpc_controller_
                .updateDisturbanceObserver(
                    odom_data_);
        }

        /**********************************************************
         * 4. DOB关闭条件
         **********************************************************/
        const bool dob_should_stop =
            dob_airborne_active_ &&
            (
                !param_.dob_enable ||
                !offboard_and_armed ||
                dob_near_ground_disable
            );

        if (dob_should_stop)
        {
            /*
            * 一旦LAND过程中低于0.10m，
            * 本次降落不再重新开启DOB。
            */
            dob_airborne_active_ =
                false;

            ommpc_controller_
                .resetDisturbanceObserver();

            if (exec_traj_state_ == LAND &&
                height_above_ground <
                    std::numeric_limits<double>::infinity())
            {
                ROS_WARN(
                    "[DOB] Disabled near ground. "
                    "height=%.3f m, threshold=%.3f m",
                    height_above_ground,
                    param_.dob_landing_disable_height);
            }
            else
            {
                ROS_WARN(
                    "[DOB] DOB deactivated.");
            }
        }

        publishDOBDebug();
        // std::cout << "exec_traj_state_:" << exec_traj_state_ << std::endl;
        // std::cout << "traj_queue size:" << trajectory_data_.traj_queue.size() << std::endl;
        // std::cout << "now_time" << now_time << std::endl;
        // std::cout << "total_traj_start_time" << trajectory_data_.total_traj_start_time << std::endl;
        // std::cout << "total_traj_end_time" << trajectory_data_.total_traj_end_time << std::endl;
        // std::cout << "first traj_start_time" << trajectory_data_.traj_queue.front().traj_start_time << std::endl;
        switch (exec_traj_state_)
        {
        case HOVER:
        {
            if (takeoff_trigger_ && !has_takeoff_)
            {
                if (state_.mode != mavros_msgs::State::MODE_PX4_OFFBOARD)
                {
                    ROS_ERROR("[MPCctrl] Not in OFFBOARD mode! Cannot takeoff.");
                    takeoff_trigger_ = false;
                    // OFFBOARD standby setpoint
                    u.bodyrates.setZero();
                    u.thrust = 0.0;
                    ret = true;
                    break;
                }
                // start_takeoff_land_time = ros::Time::now().toSec();
                if (toggle_arm_disarm(true))
                {
                    /*
                    * ARM 成功以后才正式开始起飞计时。
                    */
                    start_takeoff_land_time = ros::Time::now().toSec();
                    set_hov_with_odom();
                    // 保存本次飞行的真实地面高度
                    takeoff_ground_z_ =odom_data_.p(2);
                    takeoff_ground_z_valid_ = true;
                    is_airborne_ =false;
                    landing_detect_active_ =false;
                    clearTrajectoryCommand("takeoff started");
                    dob_airborne_active_ = false;
                    ommpc_controller_.resetDisturbanceObserver();
                    exec_traj_state_ = TAKEOFF;
                    ommpc_controller_.setHoverReference(hover_pose_);
                    ret =execMPCAndPublish(u);

                    ROS_INFO("[MPCctrl] HOVER --> TAKEOFF");
                }
                else
                {
                    ret = false;
                }
            }
            else if (land_trigger_ && is_airborne_)
            {
                if (state_.mode !=
                    mavros_msgs::State::MODE_PX4_OFFBOARD)
                {
                    ROS_ERROR(
                        "[MPCctrl] Not in OFFBOARD mode! "
                        "Cannot land.");

                    land_trigger_ = false;

                    u.bodyrates.setZero();
                    u.thrust = 0.0;

                    ret = true;
                    break;
                }

                start_takeoff_land_time =
                    ros::Time::now().toSec();

                set_hov_with_odom();

                clearTrajectoryCommand(
                    "landing started");

                /*
                * 新的一次LAND：
                * 重置接地检测和推力卸载状态。
                */
                landing_detect_active_ =
                    false;

                touchdown_unload_active_ =
                    false;

                touchdown_start_thrust_ =
                    0.0;

                last_disarm_attempt_ =
                    ros::Time(0);

                exec_traj_state_ =
                    LAND;

                /*
                * 切换状态这一周期仍然先给合法悬停控制。
                */
                ommpc_controller_
                    .setHoverReference(
                        hover_pose_);

                ret =
                    execMPCAndPublish(u);

                ROS_INFO(
                    "[MPCctrl] HOVER --> LAND");
            }
            else if (consecutive_failures_ == 0 &&
                now_time >= trajectory_data_.total_traj_start_time &&
                now_time <= trajectory_data_.total_traj_end_time &&
                trajectory_data_.exec_traj == 1 && (!trajectory_data_.traj_queue.empty())
                && is_command_mode_ && state_.mode == mavros_msgs::State::MODE_PX4_OFFBOARD && has_takeoff_ 
                && state_.armed && state_.armed &&  trajectory_ready_ )
            {
                // same as the below
                set_hov_with_odom();
                oneTraj_Data_t *traj_info = &trajectory_data_.traj_queue.front();
                traj_info = &trajectory_data_.traj_queue.front();
                trajectory_data_.total_traj_start_time = traj_info->traj_start_time;

                double traj_time = (now_time - traj_info->traj_start_time).toSec();
                /*
                * 这条轨迹开始消费。
                *
                * trajectory_ready_只用于
                * HOVER -> POLY_TRAJ 的一次性许可。
                */
                trajectory_ready_ = false;
                ommpc_controller_.setTrajectoryReference(traj_info->traj, traj_time, hover_pose_(3), traj_info->yaw_traj, odom_data_);
                ret = execMPCAndPublish(u);
                if (ret)
                {trajectory_ready_ = false;
                exec_traj_state_ = POLY_TRAJ;
                ROS_INFO("[MPCctrl] Receive the trajectory. HOVER --> POLY_TRAJ");}
            }
            else if (consecutive_failures_ == 0 &&  has_takeoff_ &&state_.armed &&
                param_.use_ref_txt && is_command_mode_ && state_.mode == mavros_msgs::State::MODE_PX4_OFFBOARD)
            {
                exec_traj_state_ = POINTS;
                ROS_INFO("[MPCctrl] Start executing traj from txt. HOVER --> POINTS");
                // same as the below
                double yaw_now = get_yaw_from_quaternion(odom_data_.q);
                get_txt_des();
                ommpc_controller_.setTextReference(quad_positions_, quad_velocities_, odom_data_, yaw_now, yaws_);
                ret = execMPCAndPublish(u);
            }
            else if (state_.mode == mavros_msgs::State::MODE_PX4_OFFBOARD && state_.armed == true)
            {
                ommpc_controller_.setHoverReference(hover_pose_);
                ret = execMPCAndPublish(u);
            }
            else
            {
                // Not in offboard: skip MPC but keep publishing so PX4 can enter offboard
                u.bodyrates.setZero();
                u.thrust = 0.0;
                ret = true;
            }
        }
        break;

        case POLY_TRAJ:
        {
            const bool trajectory_execution_safe =has_takeoff_ && state_.armed &&
                state_.mode ==mavros_msgs::State::MODE_PX4_OFFBOARD &&is_command_mode_;
            if (!trajectory_execution_safe)
            {
                ROS_ERROR(
                    "[TRAJ SAFETY] "
                    "Trajectory execution permission lost! "
                    "Abort trajectory.");
                /*
                * 立即作废整条轨迹
                */
                clearTrajectoryCommand(
                    "trajectory execution permission lost");
                /*
                * 回到当前位置悬停
                */
                set_hov_with_odom();
                exec_traj_state_ =HOVER;
                /*
                * 如果仍然处于OFFBOARD并解锁，
                * 当前周期直接给悬停MPC指令。
                */
                if (state_.armed &&state_.mode ==mavros_msgs::State::MODE_PX4_OFFBOARD)
                {
                    ommpc_controller_.setHoverReference(hover_pose_);
                    ret =execMPCAndPublish(u);
                }
                else
                {
                    /*
                    * PX4已经不接受本节点的OFFBOARD控制。
                    */
                    u.bodyrates.setZero();
                    u.thrust = 0.0;
                    ret = true;
                }

                break;
            }
            if (now_time < (trajectory_data_.total_traj_start_time) || now_time > trajectory_data_.total_traj_end_time || trajectory_data_.exec_traj != 1 || trajectory_data_.traj_queue.empty())
            {
                if (param_.use_trajectory_ending_pos && trajectory_data_.exec_traj != -1)
                {
                    // tracking the end point of the trajectory
                    // the hover pose is the end point of the trajectory
                    auto &traj_info = trajectory_data_.traj_queue.front().traj;
                    hover_pose_.head<3>() = traj_info.getJuncPos(traj_info.getPieceNum());
                    hover_pose_(3) = get_yaw_from_quaternion(odom_data_.q);
                    // std::cout << "hover_pose_ = " << hover_pose_.transpose() << std::endl;
                }
                else
                {
                    set_hov_with_odom();
                }
                ommpc_controller_.setHoverReference(hover_pose_);
                ret = execMPCAndPublish(u);
                exec_traj_state_ = HOVER;
                ROS_INFO("[MPCctrl] Stop execute the trajectory. POLY_TRAJ --> HOVER");
                trajectory_data_.exec_traj = 0;
            }
            else
            {
                set_hov_with_odom();
                // std::cout << "hover_pose_ = " << hover_pose_.transpose() << std::endl;
                oneTraj_Data_t *traj_info = &trajectory_data_.traj_queue.front();
                if (now_time < (traj_info->traj_start_time))
                { // the start time of first trajectory should be whole trajectory start time
                    trajectory_data_.total_traj_start_time = traj_info->traj_start_time;
                    ommpc_controller_.setHoverReference(hover_pose_);
                    ret = execMPCAndPublish(u);
                }
                else
                {
                    if (trajectory_data_.traj_queue.size() > 1)
                    {
                        ROS_ERROR("trajectory_data_.traj_queue.size() > 1");
                        oneTraj_Data_t *next_traj_info = &trajectory_data_.traj_queue.at(1);
                        while (now_time > next_traj_info->traj_start_time)
                        { // finish the first trajectory
                            trajectory_data_.traj_queue.pop_front();
                            traj_info = &trajectory_data_.traj_queue.front();
                            trajectory_data_.total_traj_start_time = traj_info->traj_start_time;
                            trajectory_data_.total_traj_end_time = trajectory_data_.traj_queue.back().traj_end_time;
                            if (trajectory_data_.traj_queue.size() == 1)
                            {
                                break;
                            }
                            next_traj_info = &trajectory_data_.traj_queue.at(1);
                        }
                    }
                    double traj_time = (now_time - traj_info->traj_start_time).toSec();
                    ommpc_controller_.setTrajectoryReference(traj_info->traj, traj_time, hover_pose_(3), traj_info->yaw_traj, odom_data_);
                    ret = execMPCAndPublish(u);
                }
            }
        }
        break;

        case POINTS:
        {
            const bool points_execution_safe =has_takeoff_ &&state_.armed && state_.mode ==
                    mavros_msgs::State::MODE_PX4_OFFBOARD &&is_command_mode_;
            if (!points_execution_safe)
            {
                ROS_ERROR("[TRAJ SAFETY] " "POINTS execution aborted.");
                set_hov_with_odom();
                exec_traj_state_ = HOVER;

                if (state_.armed &&state_.mode ==mavros_msgs::State::MODE_PX4_OFFBOARD)
                {
                    ommpc_controller_.setHoverReference(hover_pose_);
                    ret =execMPCAndPublish(u);
                }
                else
                {
                    u.bodyrates.setZero();
                    u.thrust = 0.0;
                    ret = true;
                }
                break;
            }
            double yaw_now = get_yaw_from_quaternion(odom_data_.q);
            get_txt_des();
			ommpc_controller_.setTextReference(quad_positions_, quad_velocities_, odom_data_, yaw_now, yaws_);
            ret = execMPCAndPublish(u);
            if (!is_command_mode_)
            {
                set_hov_with_odom();
                exec_traj_state_ = HOVER;
                ROS_INFO("[MPCctrl] Stop execute the trajectory. POINTS --> HOVER");
            }
        }
        break;

        case TAKEOFF:
        {
            takeoff_trigger_ = false;
            for (int i = 0; i < nstep + 1; ++i)
            {
                double altitude = std::min( 
                    (ros::Time::now().toSec() - start_takeoff_land_time + i * param_.step_T) * param_.takeoff_land_speed, 
                    param_.takeoff_height );
                quad_positions_[i] = Eigen::Vector3d(
                                    hover_pose_(0),
                                    hover_pose_(1),
                                    hover_pose_(2) + altitude);
                quad_velocities_[i] = Eigen::Vector3d(0.0, 0.0, param_.takeoff_land_speed);
                yaws_[i] = hover_pose_(3);
            }
            double yaw_now = get_yaw_from_quaternion(odom_data_.q);
            ommpc_controller_.setTextReference(quad_positions_, quad_velocities_, odom_data_, yaw_now, yaws_);
            ret = execMPCAndPublish(u);
            if (odom_data_.p(2) > hover_pose_(2) + param_.takeoff_height-0.1)
            {
                exec_traj_state_ = HOVER;
                set_hov_with_odom();
                ROS_INFO("[MPCctrl] TAKEOFF succeeded. TAKEOFF --> HOVER");
                has_takeoff_ = true;
                has_land_ = false;
                takeoff_complete_stamp_ =ros::Time::now();
                /*
                * 起飞完成时仍然没有合法轨迹。
                * 必须重新收到一条新轨迹才会变成true。
                */
                trajectory_ready_ = false;

    ROS_INFO(
        "[MPCctrl] TAKEOFF succeeded. "
        "TAKEOFF --> HOVER. "
        "Trajectory receiver enabled.");
            }
        }
        break;

        case LAND:
        {
            land_trigger_ = false;
            const double now_sec =ros::Time::now().toSec();
            if (exec_traj_state_ == LAND &&takeoff_ground_z_valid_)
            {
                // ROS_INFO_THROTTLE(0.5,"[LAND DOB] height=%.3f m, "
                //     "DOB=%s",
                //     height_above_ground,
                //     dob_airborne_active_
                //         ? "ON"
                //         : "OFF");
            }
            for (int i = 0;i < nstep + 1;++i)
            {
                const double elapsed =now_sec -start_takeoff_land_time +i * param_.step_T;
                const double desired_z_raw =hover_pose_(2) -elapsed *param_.takeoff_land_speed;
                double desired_z =desired_z_raw;
                double desired_vz = -param_.takeoff_land_speed;
                /*
                * 如果保存了地面高度，则参考最低只到地面。
                */
               const double touchdown_depth = 0.10;
               const double touchdown_z =takeoff_ground_z_ -touchdown_depth;

                if (takeoff_ground_z_valid_ &&desired_z <= takeoff_ground_z_)
                {
                    desired_z =touchdown_z;
                    desired_vz = 0.0;
                }
                quad_positions_[i] = Eigen::Vector3d(hover_pose_(0),hover_pose_(1),desired_z);
                quad_velocities_[i] = Eigen::Vector3d(0.0, 0.0, desired_vz);
                yaws_[i] = hover_pose_(3);
                    }
            const double yaw_now = get_yaw_from_quaternion(odom_data_.q);
            ommpc_controller_.setTextReference(quad_positions_, quad_velocities_, odom_data_, yaw_now, yaws_);
            ret = execMPCAndPublish(u);
            if (takeoff_ground_z_valid_)
            {
                /**********************************************************
                 * 1. 获取无人机真实近地状态
                 **********************************************************/

                const double height_above_ground =
                    odom_data_.p(2) -
                    takeoff_ground_z_;

                const double abs_vz =
                    std::abs(
                        odom_data_.v(2));

                const double horizontal_speed =
                    odom_data_.v.head<2>().norm();

                /**********************************************************
                 * 2. 自己的Touchdown候选条件
                 *
                 * 当前条件：
                 *
                 * 距离地面 < 8 cm
                 * 垂向速度 < 0.10 m/s
                 * 水平速度 < 0.10 m/s
                 **********************************************************/

                const bool near_ground =
                    height_above_ground < 0.08;

                const bool vertical_slow =
                    abs_vz < 0.10;

                const bool horizontal_slow =
                    horizontal_speed < 0.10;

                const bool landing_candidate =
                    near_ground &&
                    vertical_slow &&
                    horizontal_slow;

                /**********************************************************
                 * 3. 还没有进入Touchdown Unload阶段时，
                 *    才进行接地稳定时间检测
                 **********************************************************/

                if (!touchdown_unload_active_)
                {
                    if (landing_candidate)
                    {
                        /*
                        * 第一次满足近地+低速条件，
                        * 开始计时。
                        */
                        if (!landing_detect_active_)
                        {
                            landing_detect_active_ =
                                true;

                            landing_detect_start_ =
                                ros::Time::now();

                            ROS_WARN(
                                "[LAND] "
                                "Touchdown candidate detected. "
                                "Start confirmation timer.");
                        }

                        const double stable_time =
                            (ros::Time::now() -
                            landing_detect_start_)
                                .toSec();

                        /*
                        * 必须连续满足0.5秒以后，
                        * 才真正认为进入Touchdown阶段。
                        */
                        if (stable_time > 0.5)
                        {
                            touchdown_unload_active_ =
                                true;

                            touchdown_unload_start_ =
                                ros::Time::now();

                            /*
                            * 保存开始卸载瞬间的MPC推力。
                            *
                            * 例如你目前日志大约是0.19~0.20。
                            */
                            touchdown_start_thrust_ =
                                u.thrust;

                            ROS_WARN(
                                "[LAND] "
                                "Touchdown confirmed. "
                                "Start thrust unload. "
                                "height=%.3f m, "
                                "vz=%.3f m/s, "
                                "vxy=%.3f m/s, "
                                "thrust0=%.3f",
                                height_above_ground,
                                abs_vz,
                                horizontal_speed,
                                touchdown_start_thrust_);
                        }
                    }
                    else
                    {
                        /*
                        * 还没正式进入unload阶段时，
                        * 如果中间一帧不满足条件，
                        * 重新开始累计0.5秒。
                        */
                        landing_detect_active_ =
                            false;
                    }
                }

                /**********************************************************
                 * 4. Touchdown确认以后：
                 *    平滑卸载推力
                 *
                 * 注意：
                 * touchdown_unload_active_一旦true就锁存，
                 * 不再因为odom速度抖动而退出。
                 **********************************************************/

                if (ret &&
                    touchdown_unload_active_)
                {
                    const double unload_time =
                        (ros::Time::now() -
                        touchdown_unload_start_)
                            .toSec();

                    /*
                    * 从Touchdown初始推力逐渐降低到低推力。
                    *
                    * 第一轮建议0.8秒，不要突然砍推力。
                    */
                    const double unload_duration =
                        0.8;

                    double alpha =
                        unload_time /
                        unload_duration;

                    /*
                    * alpha限制在[0,1]
                    */
                    alpha =
                        std::max(
                            0.0,
                            std::min(
                                1.0,
                                alpha));

                    /*
                    * 最终Touchdown低推力。
                    *
                    * 你的send_cmd()最低还会限制到0.04，
                    * 所以这里先用0.05。
                    */
                    const double touchdown_thrust =
                        0.05;

                    /*
                    * 关键：
                    * 不再继续使用MPC本周期大约0.20的推力。
                    *
                    * 而是从进入Touchdown时保存的推力
                    * 平滑ramp到0.05。
                    */
                    u.thrust =
                        (1.0 - alpha) *
                            touchdown_start_thrust_ +
                        alpha *
                            touchdown_thrust;

                    /*
                    * 同时逐渐把body rate收敛到0。
                    *
                    * 避免已经接地以后仍然给较明显角速度命令。
                    */
                    u.bodyrates *=
                        (1.0 - alpha);

                    // ROS_INFO_THROTTLE(
                    //     0.2,
                    //     "[LAND UNLOAD] "
                    //     "height=%.3f m, "
                    //     "alpha=%.2f, "
                    //     "thrust=%.3f, "
                    //     "rates=[%.3f %.3f %.3f], "
                    //     "landed_state=%u",
                    //     height_above_ground,
                    //     alpha,
                    //     u.thrust,
                    //     u.bodyrates(0),
                    //     u.bodyrates(1),
                    //     u.bodyrates(2),
                    //     static_cast<unsigned int>(
                    //         extended_state_.landed_state));
                }

                /**********************************************************
                 * 5. PX4 Land Detector检查
                 *
                 * Touchdown unload开始以后持续观察：
                 *
                 * IN_AIR = 2
                 * ON_GROUND = 1
                 **********************************************************/

                const bool px4_on_ground =
                    extended_state_ready_ &&
                    extended_state_.landed_state ==
                        mavros_msgs::ExtendedState::
                            LANDED_STATE_ON_GROUND;

                /**********************************************************
                 * 6. 只有：
                 *
                 * Touchdown unload已经开始
                 * +
                 * PX4自己确认ON_GROUND
                 *
                 * 才允许发送DISARM。
                 **********************************************************/

                if (touchdown_unload_active_ &&
                    px4_on_ground)
                {
                    const ros::Time now =
                        ros::Time::now();

                    /*
                    * 防止高频重复调用DISARM。
                    */
                    const bool can_retry =
                        last_disarm_attempt_.isZero() ||
                        (now -
                        last_disarm_attempt_)
                            .toSec() > 1.0;

                    if (can_retry)
                    {
                        last_disarm_attempt_ =
                            now;

                        ROS_INFO(
                            "[LAND] "
                            "PX4 reports ON_GROUND. "
                            "Trying DISARM.");

                        if (toggle_arm_disarm(false))
                        {
                            /**********************************************
                             * DISARM真正成功以后，
                             * 才更新状态机最终状态。
                             **********************************************/

                            has_land_ =
                                true;

                            has_takeoff_ =
                                false;

                            is_airborne_ =
                                false;

                            dob_airborne_active_ =
                                false;

                            ommpc_controller_
                                .resetDisturbanceObserver();

                            landing_detect_active_ =
                                false;

                            touchdown_unload_active_ =
                                false;

                            touchdown_start_thrust_ =
                                0.0;

                            takeoff_ground_z_valid_ =
                                false;

                            last_disarm_attempt_ =
                                ros::Time(0);

                            exec_traj_state_ =
                                HOVER;

                            set_hov_with_odom();

                            ROS_INFO(
                                "[MPCctrl] "
                                "LAND succeeded. "
                                "LAND --> HOVER");
                        }
                        else
                        {
                            ROS_WARN(
                                "[LAND] "
                                "DISARM rejected by PX4. "
                                "Retry after 1 second.");
                        }
                    }
                }

                /**********************************************************
                 * 7. 已经开始卸载，
                 *    但PX4还没有判定ON_GROUND。
                 *
                 * 这里只打印状态，不阻止推力继续下降。
                 **********************************************************/

                if (touchdown_unload_active_ &&
                    !px4_on_ground)
                {
                    ROS_WARN_THROTTLE(
                        0.5,
                        "[LAND] "
                        "Thrust unloading, "
                        "waiting PX4 land detector. "
                        "height=%.3f m, "
                        "thrust=%.3f, "
                        "landed_state=%u",
                        height_above_ground,
                        u.thrust,
                        static_cast<unsigned int>(
                            extended_state_.landed_state));
                }

                /**********************************************************
                 * 8. LAND控制调试输出
                 *
                 * 注意这里放在thrust unload之后。
                 *
                 * 所以打印出来的是最终准备send_cmd()的推力，
                 * 而不是MPC原始推力。
                 **********************************************************/

                // ROS_INFO_THROTTLE(
                //     0.2,
                //     "[LAND CTRL] "
                //     "height=%.3f m, "
                //     "vz=%.3f m/s, "
                //     "vxy=%.3f m/s, "
                //     "thrust=%.3f, "
                //     "bodyrate=[%.3f %.3f %.3f], "
                //     "landed_state=%u, "
                //     "unload=%d",
                //     height_above_ground,
                //     odom_data_.v(2),
                //     horizontal_speed,
                //     u.thrust,
                //     u.bodyrates(0),
                //     u.bodyrates(1),
                //     u.bodyrates(2),
                //     static_cast<unsigned int>(
                //         extended_state_.landed_state),
                //     static_cast<int>(
                //         touchdown_unload_active_));
            }
            
        }
        break;

        default:
        {
            ret = false;
            exec_traj_state_ = HOVER;
            ROS_ERROR("[MPCctrl] Unknown exec_traj_state_! Jump to HOVER.");
        }

        break;
        }

        if (ret)
        {
            consecutive_failures_ = 0;
            send_cmd(u);
            last_u_ = u;
        }
        else
        {
            consecutive_failures_++;

            ROS_ERROR("[MPCctrl] Numerical error! " "failed_state=%d",static_cast<int>(state_before_control));

            /**********************************************************
             * 轨迹状态失败：立即取消轨迹
             **********************************************************/
            if (state_before_control ==POLY_TRAJ ||state_before_control ==POINTS)
            {
                clearTrajectoryCommand("MPC failure");
                set_hov_with_odom();
                exec_traj_state_ =HOVER;
            }

            /**********************************************************
             * TAKEOFF失败：
             *
             * 如果已经离地，进入空中HOVER，
             * 但不要谎称takeoff已经成功。
             **********************************************************/
            else if (state_before_control ==TAKEOFF)
            {
                set_hov_with_odom();
                exec_traj_state_ =  HOVER;
                if (is_airborne_)
                {
                    has_land_ = false;
                    ROS_ERROR("[MPCctrl] " "TAKEOFF MPC failed "
                        "after liftoff. " "Switch to AIR HOVER.");
                }
                else
                {
                    ROS_ERROR(
                        "[MPCctrl] "
                        "TAKEOFF MPC failed "
                        "before liftoff.");
                }
            }

            /**********************************************************
             * LAND失败：
             *
             * 飞机仍然是airborne，
             * 暂时转HOVER，而不是宣告已经着陆。
             **********************************************************/
            else if (
                state_before_control ==LAND)
            {
                set_hov_with_odom();
                exec_traj_state_ =HOVER;
                has_land_ = false;
                ROS_ERROR(
                    "[MPCctrl] "
                    "LAND MPC failed. "
                    "Switch to AIR HOVER.");
            }

            else
            {
                set_hov_with_odom();
                exec_traj_state_ =HOVER;
            }
        }

        if (exec_traj_state_ != LAND)
        {
            land_trigger_ = false;
        }
        if (exec_traj_state_ != TAKEOFF)
        {
            takeoff_trigger_ = false;
        }

        if(state_.mode == mavros_msgs::State::MODE_PX4_OFFBOARD && state_.armed == true && exec_traj_state_ != TAKEOFF && exec_traj_state_ != LAND)
        {
            ommpc_controller_.estimateThrustModel(imu_data_.a);
        }
        if (ros::ok())
        {
            exec_timer_.start();
        }
    }

    bool readDataFromFile()
    {
        std::string traj_path = ros::package::getPath("ommpc_controller") + param_.ref_filename;
        std::ifstream file(traj_path.c_str());
        std::string line;

        if (file.is_open())
        {
            std::cout << "File " << traj_path  << " opened." << std::endl;
            while (getline(file, line))
            {
                number_of_steps_++;
                std::istringstream linestream(line);
                std::vector<double> linedata;
                double number;

                while (linestream >> number)
                {
                    linedata.push_back(number);
                }
                test_trajectory_.push_back(linedata);
            }
            file.close();
            std::cout << "File closed successfully, " << number_of_steps_ << " lines read." << std::endl;
            return true;
        }

        return false;
    }

    void get_txt_des()
    {
        for (int cnt = line_cnt_; cnt <= line_cnt_ + nstep; cnt++)
        {
            int i = cnt - line_cnt_;
            if (nstep + cnt + 1 < number_of_steps_)
            {
                quad_positions_[i] = Eigen::Vector3d(
                                    test_trajectory_[line_cnt_+i][0],
                                    test_trajectory_[line_cnt_+i][1],
                                    test_trajectory_[line_cnt_+i][2]);
                quad_velocities_[i] = Eigen::Vector3d(
                                    test_trajectory_[line_cnt_+i][3],
                                    test_trajectory_[line_cnt_+i][4],
                                    test_trajectory_[line_cnt_+i][5]);
                yaws_[i] = test_trajectory_[line_cnt_+i][6];
            }
            else
            {
                quad_positions_[i] = Eigen::Vector3d(
                                    test_trajectory_[number_of_steps_ - 1][0],
                                    test_trajectory_[number_of_steps_ - 1][1],
                                    test_trajectory_[number_of_steps_ - 1][2]);
                quad_velocities_[i] = Eigen::Vector3d::Zero();
                yaws_[i] = test_trajectory_[number_of_steps_ - 1][6];
            }
        }
        // std::cout << quad_positions_[0] << std::endl;

        line_cnt_++;
        if (line_cnt_ > number_of_steps_)
            line_cnt_ = number_of_steps_;
        return;
    }

    template <typename TName, typename TVal>
	void read_essential_param(const ros::NodeHandle &nh, const TName &name, TVal &val)
	{
		if (nh.getParam(name, val))
		{
			// pass
		}
		else
		{
			ROS_ERROR_STREAM("Read param_: " << name << " failed.");
			ROS_BREAK();
		}
	};

public:
    OMMPC_EXAMPLE(/* args */){};
    ~OMMPC_EXAMPLE(){};
    void init(ros::NodeHandle &nh){
        enu_frame_ = true;
        // for real world flight, vel_in_body should be set to false!
        vel_in_body_ = true;
        exec_traj_state_ = HOVER;

        cmd_pub_ = nh.advertise<mavros_msgs::AttitudeTarget>("/uav1/mavros/setpoint_raw/attitude", 10);
        reference_position_pub_ =nh.advertise<geometry_msgs::PointStamped>( "reference_position",10);
        dob_raw_pub_ =
            nh.advertise<
                geometry_msgs::Vector3Stamped>(
                    "/ommpc_controller/dob/"
                    "disturbance_raw",
                    20);

        dob_filtered_pub_ =
            nh.advertise<
                geometry_msgs::Vector3Stamped>(
                    "/ommpc_controller/dob/"
                    "disturbance_filtered",
                    20);

        dob_comp_pub_ =
            nh.advertise<
                geometry_msgs::Vector3Stamped>(
                    "/ommpc_controller/dob/"
                    "disturbance_comp",
                    20);

        dob_dot_pub_ =
            nh.advertise<
                geometry_msgs::Vector3Stamped>(
                    "/ommpc_controller/dob/"
                    "disturbance_dot",
                    20);

        dob_nominal_acc_pub_ =
            nh.advertise<
                geometry_msgs::Vector3Stamped>(
                    "/ommpc_controller/dob/"
                    "nominal_acceleration",
                    20);

        dob_velocity_error_pub_ =
            nh.advertise<
                geometry_msgs::Vector3Stamped>(
                    "/ommpc_controller/dob/"
                    "velocity_error",
                    20);

        dob_status_pub_ =
            nh.advertise<
                std_msgs::Float64MultiArray>(
                    "/ommpc_controller/dob/"
                    "status",
                    20);
        set_mode_client_ = nh.serviceClient<mavros_msgs::SetMode>("/uav1/mavros/set_mode");
        arming_client_srv_ = nh.serviceClient<mavros_msgs::CommandBool>("/uav1/mavros/cmd/arming");
        odom_sub_ = nh.subscribe<nav_msgs::Odometry>("/uav1/mavros/local_position/odom", 10, &OMMPC_EXAMPLE::OdomCallback, this);
        imu_sub_ = nh.subscribe<sensor_msgs::Imu>("/uav1/mavros/imu/data", 10, &OMMPC_EXAMPLE::IMUCallback, this);
        state_sub_ = nh.subscribe<mavros_msgs::State>("/uav1/mavros/state", 10, &OMMPC_EXAMPLE::StateCallback, this);
        mpc_traj_sub_ = nh.subscribe<traj_utils::PolyTraj>("/drone_0_planning/trajectory",
                                        100,
                                        &OMMPC_EXAMPLE::MpcTrajectoryCallback,
                                        this,
                                        ros::TransportHints().tcpNoDelay());
        extended_state_sub_ =nh.subscribe<mavros_msgs::ExtendedState>("/uav1/mavros/extended_state",
                                            10,&OMMPC_EXAMPLE::ExtendedStateCallback,this);


        int trials = 0;
        while (ros::ok() && !state_.connected)
        {
            ros::spinOnce();
            ros::Duration(1.0).sleep();
            if (trials++ > 5)
                ROS_ERROR("Unable to connnect to PX4!!!");
        }

        state_change_cb_type_ = boost::bind(&OMMPC_EXAMPLE::stateChangeCallback, this, _1, _2);
        state_change_server_.setCallback(state_change_cb_type_);

        read_essential_param(nh, "takeoff_height", param_.takeoff_height);
        read_essential_param(nh, "takeoff_land_speed", param_.takeoff_land_speed);
        read_essential_param(nh, "ref_txt/enable", param_.use_ref_txt);
        read_essential_param(nh, "ref_txt/time_step", param_.ref_time_step);
        read_essential_param(nh, "ref_txt/ref_filename", param_.ref_filename);
        read_essential_param(nh, "hover_percentage", param_.hover_percent);
        read_essential_param(nh, "MPC_params/Q_pos_xy", param_.Q_pos_xy);
        read_essential_param(nh, "MPC_params/Q_pos_z", param_.Q_pos_z);
        read_essential_param(nh, "MPC_params/Q_attitude_rp", param_.Q_attitude_rp);
        read_essential_param(nh, "MPC_params/Q_attitude_yaw", param_.Q_attitude_yaw);
        read_essential_param(nh, "MPC_params/Q_velocity", param_.Q_velocity);
        read_essential_param(nh, "MPC_params/R_thrust", param_.R_thrust);
        read_essential_param(nh, "MPC_params/R_pitchroll", param_.R_pitchroll);
        read_essential_param(nh, "MPC_params/R_yaw", param_.R_yaw);
        read_essential_param(nh, "MPC_params/min_thrust", param_.min_thrust);
        read_essential_param(nh, "MPC_params/max_thrust", param_.max_thrust);
        read_essential_param(nh, "MPC_params/max_bodyrate_xy", param_.max_bodyrate_xy);
        read_essential_param(nh, "MPC_params/max_bodyrate_z", param_.max_bodyrate_z);
        read_essential_param(nh, "MPC_params/state_cost_exponential", param_.state_cost_exponential);
        read_essential_param(nh, "MPC_params/input_cost_exponential", param_.input_cost_exponential);
        read_essential_param(nh, "MPC_params/step_T", param_.step_T);
        read_essential_param(nh, "use_fix_yaw", param_.use_fix_yaw);
        read_essential_param(nh, "use_trajectory_ending_pos", param_.use_trajectory_ending_pos);
        read_essential_param(nh,"DOB/enable",param_.dob_enable);
        read_essential_param(nh,"DOB/l1",param_.dob_l1);
        read_essential_param(nh,"DOB/l2",param_.dob_l2);
        read_essential_param(nh,"DOB/lpf_tau",param_.dob_lpf_tau);
        read_essential_param(nh,"DOB/derivative_lpf_tau",param_.dob_derivative_lpf_tau);
        read_essential_param(nh,"DOB/max_acc",param_.dob_max_acc);
        read_essential_param(nh,"DOB/max_jerk",param_.dob_max_jerk);
        read_essential_param(nh,"DOB/ramp_time",param_.dob_ramp_time);
        read_essential_param(nh,"DOB/input_delay",param_.dob_input_delay);
        read_essential_param(nh,"DOB/liftoff_height",param_.dob_liftoff_height);
        read_essential_param(nh,"DOB/liftoff_vz",param_.dob_liftoff_vz);
        read_essential_param(nh,"DOB/landing_disable_height",param_.dob_landing_disable_height);
        if (param_.use_ref_txt){
            std::cout << "Ref trajectory enabled!" << std::endl;
            if (!readDataFromFile())
                std::cout << "File input error!" << std::endl;
        }

        quad_positions_.clear();
        quad_positions_.resize(nstep + 1);
        quad_velocities_.clear();
        quad_velocities_.resize(nstep + 1);
        yaws_.clear();
        yaws_.resize(nstep + 1);

        ommpc_controller_.init(param_);

        // hover_pose_ << 0.0, 0.0, 0.0, 0.0;

        exec_timer_ = nh.createTimer(ros::Duration(0.01), &OMMPC_EXAMPLE::execFSMCallback, this);
    }
};

int main(int argc, char **argv){

    ros::init(argc, argv, "ommpc_controller_example_node");
    ros::NodeHandle nh("~");

    OMMPC_EXAMPLE ommpc_example;
    ommpc_example.init(nh);

    ros::spin();

    return 0;
}
